# One Dark theme for [Thonny](https://thonny.org)

> A dark theme for [Thonny IDE](https://thonny.org).

![Screenshot](./screenshot.png)

## Install

TODO


## License

[MIT License](./LICENSE)
